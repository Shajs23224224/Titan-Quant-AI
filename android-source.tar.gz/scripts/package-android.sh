#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
: "${ANDROID_HOME:?Configure ANDROID_HOME}"
TOOLS="$ANDROID_HOME/build-tools/35.0.0"
APK=android-app/build/outputs/apk/debug/android-app-debug.apk
OUT="$(pwd)/dist/android"
mkdir -p "$OUT"
# Never preserve an earlier installer if this verification fails.
rm -f "$OUT/TITAN-QUANT-AI-v1.0.1-debug-installer.zip"
[[ -s "$APK" ]]
TEMP=$(mktemp -d)
trap 'rm -rf "$TEMP"' EXIT
cp "$APK" "$TEMP/TITAN-QUANT-AI-v1.0.1-debug.apk"
cd "$TEMP"
NAME=TITAN-QUANT-AI-v1.0.1-debug.apk
"$TOOLS/apksigner" verify --verbose --print-certs "$NAME" | tee signature.txt
"$TOOLS/aapt" dump badging "$NAME" > apk-badging.txt
grep -F "package: name='com.titanquant.ai' versionCode='13' versionName='1.0.1'" apk-badging.txt
grep -F "sdkVersion:'26'" apk-badging.txt
grep -F "targetSdkVersion:'35'" apk-badging.txt
sha256sum "$NAME" > SHA256SUMS.txt
sha256sum -c SHA256SUMS.txt
printf '%s\n' 'APK debug de investigación. Requiere servidor TITAN v1.0.0. Sin dinero real. No es una firma de producción.' > LEEME.txt
zip -q "$TEMP/installer.zip" "$NAME" SHA256SUMS.txt signature.txt apk-badging.txt LEEME.txt
unzip -t "$TEMP/installer.zip"
mv "$TEMP/installer.zip" "$OUT/TITAN-QUANT-AI-v1.0.1-debug-installer.zip"
