package com.titanquant.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import org.json.JSONArray
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE); setContent { Titan() } }
}
private val aqua=Color(0xFF40E0C0)
private suspend fun request(base:String,token:String,path:String,body:JSONObject?=null):JSONObject=withContext(Dispatchers.IO){
    val url=URL(base.trimEnd('/')+path); require(url.userInfo==null && (url.protocol=="https" || (BuildConfig.DEBUG && url.protocol=="http" && url.host in listOf("10.0.2.2","127.0.0.1","localhost")))) { "Use HTTPS (HTTP local solo en debug)" }
    val c=url.openConnection() as HttpURLConnection
    try { c.connectTimeout=5000; c.readTimeout=if(path=="/learning/train" || path=="/train" || path=="/agents/cycle" || path=="/fusion/cycle" || path=="/reasoning/cycle" || path.endsWith("/autonomous")) 120000 else 15000; c.instanceFollowRedirects=false; c.setRequestProperty("Authorization","Bearer $token"); c.setRequestProperty("Accept","application/json")
        if(body!=null){c.requestMethod="POST"; c.doOutput=true; c.setRequestProperty("Content-Type","application/json"); c.outputStream.use{it.write(body.toString().toByteArray(Charsets.UTF_8))}}
        val code=c.responseCode; val raw=(if(code in 200..299)c.inputStream else c.errorStream)?.bufferedReader()?.use{it.readText()}.orEmpty(); if(code !in 200..299) error("HTTP $code: $raw"); JSONObject(raw)
    } finally {c.disconnect()}
}
@Composable private fun Titan(){
    val ctx=LocalContext.current; val scope=rememberCoroutineScope()
    var base by remember{mutableStateOf(if(BuildConfig.DEBUG) "http://10.0.2.2:8000" else "https://")}; var token by remember{mutableStateOf("")}; var broker by remember{mutableStateOf("eToro")}; var mode by remember{mutableStateOf("observe")}
    var riskReport by remember{mutableStateOf(JSONObject())}; var page by remember{mutableStateOf("Inicio")}; var status by remember{mutableStateOf(JSONObject())}; var result by remember{mutableStateOf(JSONObject())}; var registry by remember{mutableStateOf(JSONObject())}; var learning by remember{mutableStateOf(JSONObject())}; var csv by remember{mutableStateOf("")}; var marketId by remember{mutableStateOf("")}; var interval by remember{mutableStateOf("FiveMinutes")}; var market by remember{mutableStateOf(JSONObject())}; var quote by remember{mutableStateOf(JSONObject())}; var capabilities by remember{mutableStateOf(JSONObject())}; var primary by remember{mutableStateOf(JSONObject())}; var diagnostic by remember{mutableStateOf(JSONObject())}; var modelId by remember{mutableStateOf("P001")}; var busy by remember{mutableStateOf(false)}; var msg by remember{mutableStateOf("Servidor no conectado")}
    var agents by remember{mutableStateOf(JSONObject())}; var agentRun by remember{mutableStateOf(JSONObject())}; var agentId by remember{mutableStateOf("1")}; var neuralCheck by remember{mutableStateOf(false)}
    var fusionCatalog by remember{mutableStateOf(JSONObject())}; var fusionResult by remember{mutableStateOf(JSONObject())}; var fusionBudget by remember{mutableStateOf(4)}
    var reasoning by remember{mutableStateOf(JSONObject())}; var reasonLevel by remember{mutableStateOf("auto")}; var reasonNeural by remember{mutableStateOf(true)}
    var memStatus by remember{mutableStateOf(JSONObject())}; var memHits by remember{mutableStateOf(JSONObject())}; var memQuery by remember{mutableStateOf("investigación riesgo")}; var memDataset by remember{mutableStateOf("")}
    var paperId by remember{mutableStateOf("")}; var paperSymbol by remember{mutableStateOf("SIM")}; var paperQty by remember{mutableStateOf("1")}; var paperKey by remember{mutableStateOf(UUID.randomUUID().toString())}
    var paperState by remember{mutableStateOf(JSONObject())}; var paperList by remember{mutableStateOf(JSONObject())}; var paperReply by remember{mutableStateOf(JSONObject())}; var paperOrderId by remember{mutableStateOf("")}
    var watchPaper by remember{mutableStateOf(false)}; var wsState by remember{mutableStateOf("Desconectado")}; var distributedReport by remember{mutableStateOf(JSONObject())}; var jobId by remember{mutableStateOf("")}
    val wsClient=remember{OkHttpClient.Builder().followRedirects(false).followSslRedirects(false).build()}
    DisposableEffect(watchPaper,base,token,paperId,page,broker){
        val active=AtomicBoolean(true); var socket:WebSocket?=null
        if(watchPaper && page=="Demo" && paperId.matches(Regex("[a-f0-9]{32}")) && token.isNotBlank()){
            try{
                val u=URL(base.trimEnd('/')+"/paper/ws/"+paperId)
                require(u.userInfo==null && (u.protocol=="https" || (BuildConfig.DEBUG && u.protocol=="http" && u.host in listOf("10.0.2.2","127.0.0.1","localhost")))){"Use HTTPS/WSS"}
                wsState="Conectando"
                val req=Request.Builder().url(u.toString()).header("Authorization","Bearer $token").build()
                socket=wsClient.newWebSocket(req,object:WebSocketListener(){
                    override fun onOpen(webSocket:WebSocket,response:Response){scope.launch{if(active.get())wsState="Conectado"}}
                    override fun onMessage(webSocket:WebSocket,text:String){scope.launch{if(active.get())try{val event=JSONObject(text);if(event.optString("type")=="snapshot")paperState=event.getJSONObject("data");wsState="Conectado · lectura"}catch(e:Exception){wsState="Mensaje inválido"}}}
                    override fun onClosing(webSocket:WebSocket,code:Int,reason:String){webSocket.close(code,null)}
                    override fun onClosed(webSocket:WebSocket,code:Int,reason:String){scope.launch{if(active.get())wsState="Cerrado ($code)"}}
                    override fun onFailure(webSocket:WebSocket,t:Throwable,response:Response?){scope.launch{if(active.get())wsState="Conexión interrumpida"}}
                })
            }catch(e:Exception){wsState=e.message?:"URL inválida"}
        }else{wsState="Desconectado"}
        onDispose{active.set(false);socket?.cancel()}
    }
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri-> if(uri!=null) scope.launch{try{csv=withContext(Dispatchers.IO){ctx.contentResolver.openInputStream(uri)!!.use{stream->val out=java.io.ByteArrayOutputStream(); val buf=ByteArray(8192); while(true){val n=stream.read(buf); if(n<0)break; require(out.size()+n<=2_000_000){"Archivo demasiado grande"};out.write(buf,0,n)};out.toString("UTF-8")}};msg="CSV cargado (${csv.length} caracteres)"}catch(e:Exception){msg=e.message?:"Error de archivo"}}}
    fun call(path:String,body:JSONObject?=null){ scope.launch{busy=true;if(path=="/market/candles")market=JSONObject();if(path=="/market/rate")quote=JSONObject();try{val data=request(base,token,path,body); when(path){"/paper/sessions"->{if(body==null)paperList=data else {paperId=data.getString("id");paperState=request(base,token,"/paper/sessions/"+paperId);paperKey=UUID.randomUUID().toString()}};"/distributed/jobs"->{jobId=data.optString("id");distributedReport=data};"/security/status","/distributed/status","/distributed/optimize"->distributedReport=data;"/risk/assess","/meta/status","/meta/review","/meta/restore","/audit/events"->riskReport=data;"/registry"->registry=data;"/agents/inventory"->agents=data;"/agents/cycle"->agentRun=data;"/fusion/inventory"->fusionCatalog=data;"/fusion/cycle"->fusionResult=data;"/primary/inventory"->primary=data;"/primary/diagnostic"->diagnostic=data;"/analyze"->result=data;"/reasoning/cycle"->{reasoning=data;memDataset=data.optString("input_sha256")};"/memory/status","/memory/purge"->memStatus=data;"/memory/search"->memHits=data;"/market/candles"->market=data;"/market/rate"->quote=data;"/market/capabilities","/market/demo-probe"->capabilities=data;"/learning/catalog","/learning/candidates","/learning/train","/train","/backtest"->learning=data;else->{when{path.startsWith("/paper/sessions/")->{if(body==null){if(path.endsWith("/events"))paperReply=data else paperState=data} else {paperReply=data;if(data.has("order_id"))paperOrderId=data.optString("order_id");paperState=request(base,token,"/paper/sessions/"+paperId);paperKey=UUID.randomUUID().toString()}};path.startsWith("/distributed/jobs/")->distributedReport=data;else->status=data}}};msg="Respuesta recibida: $path"}catch(e:Exception){msg=e.message?:"Error de conexión"}finally{busy=false}} }
    MaterialTheme(colorScheme=darkColorScheme(primary=aqua,background=Color(0xFF08111D),surface=Color(0xFF142638),onSurface=Color(0xFFE5EDF6))){
        Surface(Modifier.fillMaxSize()) { Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
            Text("TITAN / QUANT AI",style=MaterialTheme.typography.headlineMedium,color=aqua); Text("THNCA • v${BuildConfig.VERSION_NAME} • PAPER REPLAY",color=Color.Gray); Text("Sin ejecución real · servidor requerido",color=aqua)
            listOf(listOf("Inicio","Neuronas","Agentes"),listOf("Razón","Aprendizaje","Riesgo"),listOf("Mercado","Fusión","Memoria"),listOf("Demo","Servidor")).forEach{group->Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){group.forEach{p->FilterChip(selected=page==p,onClick={page=p},label={Text(p)})}}}
            when(page){
                "Inicio"->{
                    OutlinedTextField(base,{base=it},label={Text("URL del servidor")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                    OutlinedTextField(token,{token=it},label={Text("Token de sesión")},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth(),singleLine=true)
                    Text("Bróker seleccionado"); Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){listOf("XTB","eToro","IQ Option").forEach{b->FilterChip(broker==b,{broker=b},{Text(b)})}}
                    Text("Modo de investigación"); listOf("observe" to "Observación","research" to "Entrenamiento","paper" to "Demo local (capital virtual)","copilot" to "Copiloto informativo").forEach{(id,label)->Row{RadioButton(mode==id,{mode=id});Text(label,Modifier.padding(top=12.dp))}}
                    Text("Autónomo real: bloqueado")
                    Metric("Estado",status.optString("state","desconectado"));Metric("Bróker",status.optString("connection","sin verificar"));Metric("Saldo / posiciones","No disponibles")
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button({call("/start",JSONObject().put("broker",broker).put("mode",mode))},enabled=!busy&&token.isNotBlank()){Text("Iniciar")}; OutlinedButton({call("/pause",JSONObject())},enabled=!busy){Text("Suspender")}}
                    Button({call("/status")},enabled=!busy){Text("Consultar estado")}
                }
                "Neuronas"->{
                    Metric("Arquitectura objetivo","824 + 32 + 2 = 858"); Metric("Producción entrenada","0");Metric("Profundidad de modelos principales","16 × 2048")
                    Button({call("/primary/inventory")},enabled=!busy){Text("Cargar inventario neuronal")}
                    if(primary.has("count")){
                        Metric("Modelos materializables",primary.optInt("count").toString());Metric("Parámetros factorizados",primary.optLong("factorized_parameter_capacity").toString());Metric("Capacidad densa teórica",primary.optLong("dense_parameter_capacity").toString())
                        val models=primary.optJSONArray("models")
                        OutlinedTextField(modelId,{modelId=it.take(4).uppercase()},label={Text("ID de modelo (P001–P824)")},singleLine=true)
                        val selected=models?.let{arr->(0 until arr.length()).map{arr.getJSONObject(it)}.firstOrNull{it.optString("id")==modelId}}
                        if(selected!=null){Text(selected.toString(2),style=MaterialTheme.typography.bodySmall);Button({call("/primary/diagnostic",JSONObject().put("ids",JSONArray().put(modelId)))},enabled=!busy&&mode=="research"){Text("Diagnóstico sintético (investigación)")}}
                    }
                    Text(diagnostic.toString(2),style=MaterialTheme.typography.bodySmall)
                    Text("Redes inicializadas bajo demanda. No hay predicciones calibradas ni pesos financieros desplegados.")
                }
                "Fusión"->{
                    Metric("Arquitectura","32 intermedias + 2 finales")
                    Text("Diagnóstico de modelos sin entrenamiento financiero. No son señales de inversión.")
                    Button({call("/fusion/inventory")},enabled=!busy){Text("Inventario de fusión")}
                    Metric("Modelos",fusionCatalog.optString("count","—"));Metric("Parámetros",fusionCatalog.optString("trainable_parameters","—"))
                    Button({picker.launch(arrayOf("text/*","application/octet-stream"))}){Text("Importar CSV")}
                    Text("Presupuesto de primarias sintéticas: $fusionBudget")
                    Slider(value=fusionBudget.toFloat(),onValueChange={fusionBudget=it.toInt()},valueRange=0f..16f,steps=15)
                    Button({fusionResult=JSONObject();call("/fusion/cycle",JSONObject().put("csv",csv).put("primary_budget",fusionBudget))},enabled=!busy&&csv.isNotBlank()&&mode=="research"){Text("Ejecutar fusión experimental")}
                    if(fusionResult.has("decision")){
                        Metric("Decisión segura",fusionResult.optString("decision"));Metric("Propuesta no operativa",fusionResult.optJSONObject("proposal")?.optString("action")?:"—")
                        Metric("Dictamen neuronal no calibrado",fusionResult.optJSONObject("neural_risk")?.optString("candidate_verdict")?:"—")
                        Text("Veto independiente: "+(fusionResult.optJSONObject("gate")?.optJSONArray("reasons")?.toString(2)?:"—"))
                        Text("Primarias seleccionadas: "+fusionResult.optJSONArray("primary_ids"))
                        Text("Redes intermedias: "+fusionResult.optJSONArray("intermediate_ids"))
                        Text("Contexto agéntico: "+fusionResult.optJSONObject("agent_context")?.toString(2))
                    }
                }
                "Agentes"->{
                    Metric("Roles de investigación","160 / 16 departamentos")
                    Text("Deliberación histórica; no realiza operaciones ni predicciones calibradas.")
                    Button({call("/agents/inventory")},enabled=!busy){Text("Cargar inventario de agentes")}
                    Metric("Herramientas implementadas",agents.optString("implemented_tools","—"));Metric("Dependencias pendientes",agents.optString("dependency_blocked","—"))
                    Button({picker.launch(arrayOf("text/*","application/octet-stream"))}){Text("Importar OHLCV CSV")}
                    Row { Checkbox(neuralCheck,{neuralCheck=it});Text("Diagnóstico neuronal sintético (solo investigación)",Modifier.padding(top=12.dp)) }
                    Button({agentRun=JSONObject();call("/agents/cycle",JSONObject().put("csv",csv).put("diagnostic_budget",if(neuralCheck)4 else 0))},enabled=!busy&&csv.isNotBlank()){Text("Ejecutar deliberación")}
                    if(agentRun.has("run_id")){
                        Metric("Observaciones / abstenciones","${agentRun.optInt("observed")} / ${agentRun.optInt("abstained")}")
                        Metric("Decisión",agentRun.optString("decision"));Metric("Mensajes",(agentRun.optJSONArray("messages")?.length()?:0).toString())
                        Text(agentRun.optJSONObject("deliberation")?.toString(2)?:"",style=MaterialTheme.typography.bodySmall)
                        Text(agentRun.optJSONObject("neural_diagnostic")?.toString(2)?:"Sin diagnóstico sintético",style=MaterialTheme.typography.bodySmall)
                    }
                    OutlinedTextField(agentId,{agentId=it.filter{c->c.isDigit()}.take(3)},label={Text("ID de agente (1–160)")},singleLine=true)
                    val id=agentId.toIntOrNull()
                    val catalog=agents.optJSONArray("agents")
                    val item=catalog?.let{arr->(0 until arr.length()).map{arr.getJSONObject(it)}.firstOrNull{it.optInt("id")==id}}
                    if(item!=null) Text(item.toString(2),style=MaterialTheme.typography.bodySmall)
                    val outputs=agentRun.optJSONArray("results")
                    val output=outputs?.let{arr->(0 until arr.length()).map{arr.getJSONObject(it)}.firstOrNull{it.optInt("id")==id}}
                    if(output!=null)Text(output.toString(2),style=MaterialTheme.typography.bodySmall)
                }
                "Mercado"->{
                    Text("Datos financieros · solo lectura",style=MaterialTheme.typography.titleLarge)
                    Text("eToro: inicie sesión de observación; configure las claves en el servidor. XTB e IQ Option: CSV autorizado en Razón.")
                    Button({call("/market/capabilities")},enabled=!busy){Text("Consultar capacidades")}
                    Text(capabilities.toString(2),style=MaterialTheme.typography.bodySmall)
                    OutlinedTextField(marketId,{marketId=it.filter{c->c.isDigit()}.take(10)},label={Text("ID de instrumento eToro")},singleLine=true,modifier=Modifier.fillMaxWidth())
                    listOf(listOf("OneMinute" to "1m","FiveMinutes" to "5m","FifteenMinutes" to "15m"),listOf("OneHour" to "1h","FourHours" to "4h","OneDay" to "1d")).forEach{group->Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){group.forEach{(id,label)->FilterChip(interval==id,{interval=id},{Text(label)})}}}
                    val id=marketId.toIntOrNull(); val canRead=!busy&&id!=null&&id>0&&broker=="eToro"
                    val req=JSONObject().put("instrument",id?:0).put("interval",interval).put("count",100)
                    Button({call("/market/candles",req)},enabled=canRead){Text("Consultar velas cerradas")}
                    OutlinedButton({call("/market/rate",req)},enabled=canRead){Text("Consultar cotización")}
                    OutlinedButton({call("/market/demo-probe")},enabled=!busy&&broker=="eToro"){Text("Probar lectura demo")}
                    Metric("Cotización (no streaming)",if(quote.has("bid")) "ID ${quote.optInt("instrument")} · Bid ${quote.optDouble("bid")} / Ask ${quote.optDouble("ask")}" else "Sin datos")
                    Text(quote.toString(2),style=MaterialTheme.typography.bodySmall)
                    market.optJSONArray("chart")?.let{ChartCandles(it)}
                    Metric("Origen",market.optString("source","Sin datos"));Text("Instrumento: ${market.optString("instrument","—")}")
                    Text("Calidad: ${market.optJSONObject("quality")?.toString(2)?:"Sin datos"}");Text("Percepción: ${market.optJSONObject("perception")?.toString(2)?:"Sin datos"}")
                }
                "Razón"->{
                    Text("Deep Cognitive Reasoning Engine",style=MaterialTheme.typography.titleLarge)
                    Text("Escenarios históricos condicionales; no son predicciones calibradas. Sin ejecución.")
                    Button({picker.launch(arrayOf("text/*","application/octet-stream"))}){Text("Importar OHLCV CSV")}
                    OutlinedButton({call("/analyze",JSONObject().put("csv",csv))},enabled=!busy&&csv.isNotBlank()){Text("Análisis de percepción F2")}
                    Metric("Decisión de percepción",result.optString("decision","Sin análisis"));result.optJSONArray("chart")?.let{ChartCandles(it)};Text(JSONObject(result.toString()).apply{remove("chart")}.toString(2),style=MaterialTheme.typography.bodySmall)
                    Text("Presupuesto de razonamiento")
                    listOf(listOf("auto" to "Auto","quick" to "Rápido"),listOf("standard" to "Normal","deep" to "Profundo")).forEach{group->Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){group.forEach{(id,label)->FilterChip(reasonLevel==id,{reasonLevel=id},{Text(label)})}}}
                    Row{Checkbox(checked=reasonNeural,onCheckedChange={reasonNeural=it});Text("Diagnóstico neuronal experimental",Modifier.padding(top=12.dp))}
                    Button({reasoning=JSONObject();call("/reasoning/cycle",JSONObject().put("csv",csv).put("level",reasonLevel).put("primary_budget",fusionBudget).put("with_neural",reasonNeural))},enabled=!busy&&csv.isNotBlank()&&mode=="research"){Text("Ejecutar razonamiento F6")}
                    if(reasoning.has("world")){
                        Metric("Decisión",reasoning.optString("decision"));Metric("Régimen histórico",reasoning.optJSONObject("world")?.optString("regime")?:"—")
                        Metric("Presupuesto aplicado",reasoning.optJSONObject("budget")?.optString("selected")?:"—")
                        val graph=reasoning.optJSONObject("knowledge_graph")
                        Metric("Grafo de conocimiento","${graph?.optJSONArray("nodes")?.length()?:0} nodos / ${graph?.optJSONArray("edges")?.length()?:0} aristas")
                        listOf("world","budget","agents","deductive_rules","inductive","hypotheses","scenarios","counterfactuals","causal","plan","neural","memory_context","memory_consolidation").forEach{key->Text(key,color=aqua,style=MaterialTheme.typography.titleSmall);Text(reasoning.opt(key)?.toString()?:"No disponible",style=MaterialTheme.typography.bodySmall)}
                    }
                }
                "Memoria"->{
                    Text("Cognitive Memory Engine",style=MaterialTheme.typography.titleLarge)
                    Text("Memorias del servidor. Recuperación léxica vectorial; no evidencia financiera verificada.")
                    Button({call("/memory/status")},enabled=!busy){Text("Consultar ocho memorias")}
                    Text(memStatus.toString(2),style=MaterialTheme.typography.bodySmall)
                    OutlinedTextField(memQuery,{memQuery=it},label={Text("Buscar conocimientos")},modifier=Modifier.fillMaxWidth())
                    OutlinedTextField(memDataset,{memDataset=it},label={Text("SHA-256 del dataset (opcional)")},modifier=Modifier.fillMaxWidth())
                    Button({memHits=JSONObject();call("/memory/search",JSONObject().put("query",memQuery).put("dataset",memDataset).put("limit",8))},enabled=!busy&&memQuery.isNotBlank()){Text("Buscar memoria contextual")}
                    Text(memHits.toString(2),style=MaterialTheme.typography.bodySmall)
                    OutlinedButton({call("/memory/purge",JSONObject())},enabled=!busy){Text("Purgar registros vencidos")}
                    Text("Eliminación completa: endpoint autenticado /memory/delete con sesión suspendida y confirmación explícita.")
                }
                "Aprendizaje"->{var series by remember{mutableStateOf("research-series")};var parent by remember{mutableStateOf("")};OutlinedTextField(series,{series=it},label={Text("Identificador de serie")});OutlinedTextField(parent,{parent=it},label={Text("ID candidato anterior (opcional)")});Button({val payload=JSONObject().put("csv",csv).put("series",series).put("epochs",2);if(parent.isNotBlank())payload.put("parent_id",parent);call("/learning/train",payload)},enabled=!busy&&csv.isNotBlank()&&series.isNotBlank()){Text("Entrenar red primaria F8")};OutlinedButton({call("/learning/candidates")},enabled=!busy){Text("Consultar candidatos persistentes")};Text("Entrenamiento experimental remoto. Requiere sesión de investigación.");Button({picker.launch(arrayOf("text/*","application/octet-stream"))}){Text("Importar CSV")};Button({call("/train",JSONObject().put("csv",csv).put("epochs",12))},enabled=!busy&&csv.isNotBlank()){Text("Entrenar candidato")};OutlinedButton({call("/backtest",JSONObject().put("csv",csv))},enabled=!busy&&csv.isNotBlank()){Text("Backtest de referencia")};Text(learning.toString(2))}
                "Demo"->{
                    Text("Simulador histórico local",style=MaterialTheme.typography.titleLarge)
                    Text("No conecta a cuentas demo de bróker. Inicie Demo local en Inicio. Compra/venta manual o ciclo autónomo experimental; ejecución en la apertura de la siguiente vela; solo posiciones largas y unidades enteras.")
                    Button({picker.launch(arrayOf("text/*","application/octet-stream"))}){Text("Importar histórico OHLCV")}
                    OutlinedTextField(paperSymbol,{paperSymbol=it.take(40)},label={Text("Símbolo de simulación")},singleLine=true)
                    Button({call("/paper/sessions",JSONObject().put("csv",csv).put("symbol",paperSymbol).put("key",paperKey))},enabled=!busy&&csv.isNotBlank()&&paperSymbol.isNotBlank()){Text("Crear sesión virtual (100.000 u.m.)")}
                    OutlinedButton({call("/paper/sessions")},enabled=!busy){Text("Sesiones persistentes")}
                    val saved=paperList.optJSONArray("sessions")
                    if(saved!=null){for(i in 0 until saved.length()){val item=saved.getJSONObject(i);TextButton({watchPaper=false;paperId=item.getString("id");paperState=JSONObject()}){Text(item.optString("symbol")+" · "+item.optString("state")+" · "+item.optString("id").take(8))}}}
                    OutlinedTextField(paperId,{watchPaper=false;paperId=it.take(32);paperState=JSONObject()},label={Text("ID de sesión virtual")},singleLine=true)
                    val valid=paperId.matches(Regex("[a-f0-9]{32}"));val path="/paper/sessions/"+paperId
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedButton({call(path)},enabled=!busy&&valid){Text("Actualizar")};OutlinedButton({call(path+"/resume",JSONObject())},enabled=!busy&&valid){Text("Reanudar")}}
                    Row{Checkbox(watchPaper,{watchPaper=it},enabled=valid);Text("Supervisión WebSocket: $wsState",Modifier.padding(top=12.dp))}
                    Metric("Estado / vela",paperState.optString("state","—")+" / "+paperState.optString("cursor","—"))
                    Metric("Patrimonio virtual",if(paperState.has("equity_cents"))String.format(java.util.Locale.US,"%.2f",paperState.optLong("equity_cents")/100.0) else "—")
                    Metric("Posición (unidades)",paperState.optString("quantity","—"));Metric("Reconciliación",paperState.optJSONObject("reconciliation")?.optString("ok")?:"—")
                    OutlinedTextField(paperQty,{paperQty=it.filter{c->c.isDigit()}.take(7)},label={Text("Cantidad entera")},singleLine=true)
                    OutlinedTextField(paperKey,{paperKey=it.take(80)},label={Text("Clave de solicitud (reutilice al reintentar)")},singleLine=true)
                    TextButton({paperKey=UUID.randomUUID().toString()}){Text("Nueva clave (solo para nueva acción)")}
                    val qty=paperQty.toIntOrNull()?:0;val active=!busy&&valid&&paperKey.length>=8
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){Button({call(path+"/orders",JSONObject().put("key",paperKey).put("side","buy").put("quantity",qty))},enabled=active&&qty>0){Text("Compra virtual")};OutlinedButton({call(path+"/orders",JSONObject().put("key",paperKey).put("side","sell").put("quantity",qty))},enabled=active&&qty>0){Text("Venta virtual")}}
                    Button({call(path+"/advance",JSONObject().put("key",paperKey))},enabled=active){Text("Avanzar una vela")}
                    Text("Autonomía experimental: análisis DCRE de velas ya vistas, reglas virtuales fijas y veto de riesgo. No usa logits sin validar ni opera con dinero real.")
                    Button({call(path+"/autonomous",JSONObject().put("key",paperKey).put("steps",5))},enabled=active){Text("Ejecutar 5 ciclos autónomos virtuales")}
                    OutlinedTextField(paperOrderId,{paperOrderId=it.take(32)},label={Text("ID de orden pendiente")},singleLine=true)
                    OutlinedButton({call(path+"/cancel",JSONObject().put("key",paperKey).put("order_id",paperOrderId))},enabled=active&&paperOrderId.length==32){Text("Cancelar orden")}
                    OutlinedButton({call(path+"/events")},enabled=!busy&&valid){Text("Eventos de ejecución virtual")}
                    Text(paperReply.toString(2),style=MaterialTheme.typography.bodySmall);Text(paperState.toString(2),style=MaterialTheme.typography.bodySmall)
                }
                "Servidor"->{
                    Text("Investigación concurrente y optimización CPU",style=MaterialTheme.typography.titleLarge)
                    Text("Requiere modo Investigación. La cola es local; INT8 es un diagnóstico sintético, no un modelo desplegado.")
                    OutlinedButton({call("/distributed/status")},enabled=!busy){Text("Topología del servidor")}
                    OutlinedButton({call("/security/status")},enabled=!busy){Text("Seguridad y recursos")}
                    Button({picker.launch(arrayOf("text/*","application/octet-stream"))}){Text("Importar histórico")}
                    Button({call("/distributed/jobs",JSONObject().put("csv",csv))},enabled=!busy&&csv.isNotBlank()){Text("Enviar análisis a la cola")}
                    OutlinedTextField(jobId,{jobId=it.take(32)},label={Text("ID del trabajo")},singleLine=true)
                    OutlinedButton({call("/distributed/jobs/"+jobId)},enabled=!busy&&jobId.length==32){Text("Consultar trabajo")}
                    Button({call("/distributed/optimize",JSONObject().put("domains",JSONArray().put("prediction")).put("targets",JSONArray().put("future_log_return")).put("horizon",1).put("budget",2).put("repeats",5))},enabled=!busy){Text("Comparar FP32 / INT8")}
                    Text(distributedReport.toString(2),style=MaterialTheme.typography.bodySmall)
                }
                "Riesgo"->{var candidate by remember{mutableStateOf("")};var riskSeries by remember{mutableStateOf("research-series")}; Button({call("/risk/assess",JSONObject().put("csv",csv))},enabled=!busy&&csv.isNotBlank()){Text("VaR / ES histórico (hipotético)")};OutlinedButton({call("/meta/status")},enabled=!busy){Text("Supervisión de modelos y agentes")};OutlinedTextField(candidate,{candidate=it},label={Text("ID checkpoint")});OutlinedTextField(riskSeries,{riskSeries=it},label={Text("Serie")});OutlinedButton({call("/meta/review",JSONObject().put("candidate_id",candidate).put("series",riskSeries))},enabled=!busy&&candidate.length==32){Text("Evaluar checkpoint")};OutlinedButton({call("/meta/restore",JSONObject().put("candidate_id",candidate).put("series",riskSeries).put("confirmation","RESEARCH ONLY"))},enabled=!busy&&candidate.length==32){Text("Seleccionar checkpoint de investigación")};OutlinedButton({call("/audit/events")},enabled=!busy){Text("Auditoría local")};Text(riskReport.toString(2));Metric("Ejecución real","Deshabilitada");Text("Motor independiente F9: límites de investigación, no conectados a ejecución real. Demo local usa controles deterministas propios.");Text("Memorias: "+(status.optJSONObject("memory_counts")?.toString(2)?:"sin datos"))}
            }
            Button({call("/emergency",JSONObject())},colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF9A243D),contentColor=Color.White),modifier=Modifier.fillMaxWidth(),enabled=token.isNotBlank()){Text("PARADA DE EMERGENCIA REMOTA")}
            Text(if(busy) "Solicitud en curso • $msg" else msg,style=MaterialTheme.typography.bodySmall);Text("La parada requiere conexión al servidor. No hay órdenes reales habilitadas.",style=MaterialTheme.typography.bodySmall)
        }}
    }
}
@Composable private fun Metric(label:String,value:String){Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){Text(label,color=Color.LightGray);Text(value,color=aqua,style=MaterialTheme.typography.titleMedium)}}}

@Composable private fun ChartCandles(data:JSONArray){
    val bars=remember(data){(maxOf(0,data.length()-60) until data.length()).map{data.getJSONObject(it)}}
    if(bars.isEmpty()) return
    val lo=bars.minOf{it.getDouble("low")};val hi=bars.maxOf{it.getDouble("high")};val range=(hi-lo).coerceAtLeast(1e-12)
    Text("Velas OHLC · últimas ${bars.size}")
    Text("Máximo: $hi",style=MaterialTheme.typography.bodySmall)
    Canvas(Modifier.fillMaxWidth().height(220.dp).background(Color(0xFF101D2C))){
        val step=size.width/bars.size; val pad=8.dp.toPx(); fun y(p:Double):Float=pad+((hi-p)/range).toFloat()*(size.height-2*pad)
        bars.forEachIndexed{i,b->val x=(i+.5f)*step;val o=b.getDouble("open");val c=b.getDouble("close");val color=if(c>=o)aqua else Color(0xFFFF657A);drawLine(color,Offset(x,y(b.getDouble("high"))),Offset(x,y(b.getDouble("low"))),strokeWidth=1.2.dp.toPx());drawRect(color,Offset(x-step*.3f,minOf(y(o),y(c))),Size(step*.6f,maxOf(1f,kotlin.math.abs(y(o)-y(c)))))}
    }
    Text("Mínimo: $lo · separación uniforme por vela, no por tiempo",style=MaterialTheme.typography.bodySmall)
}
